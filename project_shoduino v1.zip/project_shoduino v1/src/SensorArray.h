#ifndef SensorArray_h
#define SensorArray_h

#include <Arduino.h>

class SensorArray {
    public:
        void begin(const int pins[8], int emitterPin);
        void calibrate();
        int getPos();
        bool isOut();
	
	int sensorPins[8];
	int sensorMin[8];
        int sensorMax[8];

    private:

        int emitterPin;
        bool outside = false;
        int lastPosition = 3500;
};

#endif