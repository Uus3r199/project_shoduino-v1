#ifndef Shoduino_h
#define Shoduino_h

#include <Arduino.h>
#include <EEPROM.h>
#include "SensorArray.h"
#include "MotorController.h"
#include "PIDController.h"

class Shoduino {
  public:
    // Sub-systems
    MotorController motorLeft;
    MotorController motorRight;
    SensorArray sensors;
    PIDController pid;

    // Core Functions
    void begin(int buttonPin, int buzzerPin);
    void calibrate();
    void stop();
    
    // UI Functions
    void waitForButton();
    void beep(int duration = 150);
    
    void handleRecovery(int lastError);
    void runCalibration(int buttonPin);
    void vasCalibration();
    bool serCalibration();

  private:
    int _buttonPin;
    int _buzzerPin;
};

#endif