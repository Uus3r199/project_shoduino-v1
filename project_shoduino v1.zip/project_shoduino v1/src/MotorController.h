#ifndef MotorController_h
#define MotorController_h

#include <Arduino.h>

class MotorController {
    public:
        void begin(int in1, int in2, int pwm);
        void setSpeed(int speed);
        void stop();

    private:
        int pinIN1;
        int pinIN2;
        int pinPWM;
};

#endif